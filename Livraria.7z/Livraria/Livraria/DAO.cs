﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data;
using MySql.Data.MySqlClient;

namespace Livraria
{
    class DAO
    {
        public MySqlConnection conexao;
        public string dados;
        public string comando;
        public string resultado;
        public int i;
        public string msg;
        public int contador;
        public int[] codigo;//vetor de codigo
        public string[] nomeCompleto;//vetor de nome
        public string[] endereco;//vetor de endereco
        public string[] telefone;//vetor de telefone
        public DateTime[] dataNascimento;//vetor de data
        public string[] login;//vetor de login
        public string[] senha;//vetor de senhas






        public DAO()
        {
            //Script para o banco de dados
            conexao = new MySqlConnection("server=localhost;DataBase=LivrariaBD;Uid=root;Password=; Convert Zero DateTime = True");
            try
            {
                conexao.Open();//tentando conectar ao BD               
            }
            catch(Exception e)
            {
                Console.WriteLine("Algo deu Errado! \n\n" + e);//mostrar o erro em tela
                Console.ReadLine();//manter o prompt aberto
                conexao.Close();//Fechar a conexao com o banco de dados
            }
        }//fim do metodo construtor










        //Metodo para inserir os dados no BN
        public void Inserir(string nomeCompleto, string endereco, string telefone, DateTime dataNascimento, string login, string senha)
        {
            try
            {
                //modefiicar a estrutura de dados 
                MySqlParameter parameter = new MySqlParameter();
                parameter.ParameterName = "@Date";
                parameter.MySqlDbType = MySqlDbType.Date;
                parameter.Value = dataNascimento.Year + "-" + dataNascimento.Month + "-" + dataNascimento.Day; 


                dados = "('','" + nomeCompleto + "','" + endereco + "','" + telefone + "','" + dataNascimento + "','" + login + "','" + senha + "')";
                comando = "Insert into pessoa(codigo, nome, endereco, telefone, dataDeNascimento, login , senha) values" + dados;
               
                
                
                //Executar  o comando de inserção no banco de dados
                MySqlCommand sql = new MySqlCommand(comando, conexao);
                resultado = "" + sql.ExecuteNonQuery();//Executa o insert no BD
                Console.WriteLine(resultado + "Linhas Afetadas");
            }
            catch(Exception e)
            {
                Console.WriteLine("Algo deu Errado!\n\n" + e);
                Console.ReadLine();//Manter o programa aberto
            }
        }//fim do metodo inserir






        public void PreencherVetor()
        {
            string query = "select * from Pessoa";//coletar dados do BD

            //Instanciar
            codigo = new int[100];
            nomeCompleto = new string[100];
            endereco = new string[100];
            telefone = new string[100];
            dataNascimento = new DateTime[100];
            login = new string[100];
            senha = new string[100];



            //Preencher com valores iniciais 
            for (i = 0; i < 100; i++)
            {
                codigo[i] = 0;
                nomeCompleto[i] = "";
                endereco[i] = "";
                telefone[i] = "";
                dataNascimento[i] = new DateTime();
                login[i] = "";
                senha[i] = "";
            }//fim do for


            //criando um comando para a consulta do banco de dados
            MySqlCommand coletar = new MySqlCommand(query, conexao);
            //lietura dos dados no banco 
            MySqlDataReader leitura = coletar.ExecuteReader();


            i = 0;
            contador = 0;
            while(leitura.Read())
            {
                codigo[i] = Convert.ToInt32(leitura["codigo"]);
                nomeCompleto[i] = leitura["nome"] + "";
                endereco[i] = leitura["endereco"] + "";
                telefone[i] = leitura["telefone"] + "";
                dataNascimento[i] = Convert.ToDateTime(leitura["dataDeNascimento"]);
                login[i] = leitura["login"] + "";
                senha[i] = leitura["senha"] + "";
                i++;
                contador++;
            }//fim do while


            //fechar leitura de dados no banco
            leitura.Close();

        }//fim do metodo preeenchimento de vetor











        public string ConsultarTudo()
        {
            //preencher os vetores
            PreencherVetor();


            msg = "";
            for (i = 0; i < contador; i++)
            {
                msg += "Codigo: " + codigo[i] +
                        ", Nome: " + nomeCompleto[i] +
                        ", Endereco: " + endereco[i] +
                        ", Telefone: " + telefone[i] +
                        ", Data de Nacimento: " + dataNascimento[i] +
                        ", Login: " + login[i] +
                        ", Senha: " + senha[i] +
                        "\n\n";
            }//fim do for


            return msg;

        }//fim do metodo consultar tudo






        public string ConsultarTudo(int cod)
        {
            PreencherVetor();
            for (i = 0; i < contador; i++)
            {
                if (codigo[i] == cod)
                {
                    msg = "Codigo: " + codigo[i] +
                    ", Nome: " + nomeCompleto[i] +
                    ", Endereço: " + endereco[i] +
                    ", Telefone: " + telefone[i] +                    
                    ", Data de Nascimento: " + dataNascimento[i] +
                    ", Login: " + login[i] +
                    ", Senha: " + senha[i] +
                    "\n\n";
                    return msg;
                }
            }//fim do for


            return "Codigo informado não encontrado";
        }//fim consultar codigo 











        public string Atualizar(int codigo, string campo, string novoDado)
        {
            try
            {
                string query = "update pessoa set " + campo + " = '" + novoDado + "' where codigo = '" + codigo + "'";
                //executar o comando
                MySqlCommand sql = new MySqlCommand(query, conexao);
                string resultado = "" + sql.ExecuteNonQuery();
                return resultado + "Linhas Afetadas";
            }
            catch (Exception e)
            {
                return "Algo deu errado!\n\n" + e;
            }
        }//fim do metodo atualizar









        public string Deletar(int codigo)
        {
            try
            {
                string query = "delete from Pessoa where codigo = '" + codigo + "'";
                //executar o comando
                MySqlCommand sql = new MySqlCommand(query, conexao);
                string resultado = "" + sql.ExecuteNonQuery();
                return resultado + "Linhas Afetadas";
            }
            catch (Exception e)
            {
                return "Algo deu errado!\n\n" + e;
            }
        }//fim do metodo deletar








    }//fim da classe
}//fim do projeto
