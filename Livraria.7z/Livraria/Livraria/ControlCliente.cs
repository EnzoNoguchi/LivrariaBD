﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Livraria
{
    class ControlCliente
    {
        DAO conexao;//criando a variavel conexao
        ModelCliente modelCliente;//conectando a model a control
        ControlLivros livros;
        ModelFuncionario modelFuncionario;
        DAOFuncionario conexaoFuncionario;
      

        public DateTime dataNascimento;
        private int opcao;
        private int menu;
        private int cargo;
        private int codigoFuncionario;
        private int menuCliente;




        public ControlCliente()
        {
            modelCliente = new ModelCliente();
            conexao = new DAO();//instanciando a variavel conexao
            livros = new ControlLivros();
            dataNascimento = new DateTime();
            modelFuncionario = new ModelFuncionario();
            conexaoFuncionario = new DAOFuncionario();
        }//fim do contrutor




        //==============================================================================================================================================================================================



        public int AcessarOpcao
        {
            get
            {
                return opcao;
            }
            set
            {
                this.opcao = value;
            }
        }//fim da opcao





        public int AcessarMenu
        {
            get
            {
                return menu;
            }
            set
            {
                this.menu = value;
            }
        }//fim da opcao





        public int AcessarCargo
        {
            get
            {
                return cargo;
            }
            set
            {
                this.cargo = value;
            }
        }//fim da opcao






        public int AcessarMenuCliente
        {
            get
            {
                return menuCliente;
            }
            set
            {
                this.menuCliente = value;
            }
        }//fim da opcao








        //==========================================================================   Cliente e Funcionario    =============================================================================================











        public void MenuCargo()
        {
            Console.WriteLine("Escolha uma das opções abaixo: \n\n" +
                              "1. Cliente \n" +
                              "2. Funcionario");
            AcessarCargo = Convert.ToInt32(Console.ReadLine());
        }//fim do metodo menu cargo







        public void ExecutarMenuCargo()
        {
            do
            {
                MenuCargo();
                //executando a ação
                switch (AcessarCargo)
                {
                    case 0:
                        Console.WriteLine("Obrigado!");
                        break;


                    case 1:


                        Console.Clear();
                        ExecutarMenuFuncionario();
                        break;







                    case 2:

                        Console.Clear();
                        ExecutarMenu();
                        break;

                }


            } while (AcessarMenu != 0);
        }//fim do executar menu





















        //===============================================================  Menu Funcionario    =========================================================================================













        public void MenuFuncionario()
        {
            Console.WriteLine("Escolha uma das opções abaixo: \n\n" +
                              "1. Cadastrar \n" +
                              "2. Login");
            AcessarMenu = Convert.ToInt32(Console.ReadLine());
        }//fim do metodo menu




        public void ExecutarMenuFuncionario()
        {
            do
            {
                MenuFuncionario();
                //executando a ação
                switch (AcessarMenu)
                {
                    case 0:
                        Console.WriteLine("Obrigado!");
                        break;


                    case 1:
                        Console.WriteLine("Crie um login: ");
                        string loginFuncionario = Convert.ToString(Console.ReadLine());
                        Console.WriteLine("Crie um senha: ");
                        string senhaFuncionario = Convert.ToString(Console.ReadLine());
                        Console.WriteLine("Informe um nome: ");
                        string nomeCompletoFuncionario = Console.ReadLine();
                        Console.WriteLine("Informe um telefone: ");
                        string telefoneFuncionario = Console.ReadLine();
                        Console.WriteLine("informe um endereço: ");
                        string enderecoFuncionario = Console.ReadLine();
                        Console.WriteLine("informe sua data de nascimento: ");
                        DateTime dataNascimentoFuncionario = Convert.ToDateTime(Console.ReadLine());

                        
                        Console.Clear();
                        Console.WriteLine("Cadastro com Sucesso!");
                        conexaoFuncionario.InserirFuncionario(nomeCompletoFuncionario, enderecoFuncionario, telefoneFuncionario, dataNascimentoFuncionario, loginFuncionario, senhaFuncionario);
                        break;

                    case 2:
                        //Pedir para o usuario digitar um codigo
                        Console.WriteLine("Informe o codigo: ");
                        codigoFuncionario = Convert.ToInt32(Console.ReadLine());
                        //mostrar o resultado da operação
                        Console.WriteLine(modelFuncionario.ConsultarFuncionario(codigoFuncionario));
                        Console.Clear();
                        Executar();
                        break;


                }


            } while (AcessarMenu != 0);
        }//fim do executar menu
































        //===============================================================   Primeiro   Menu    =============================================================================================






        public void PrimeiroMenu()
        {
            Console.WriteLine("Escolha uma das opções abaixo: \n\n" +
                              "1. Cadastrar \n" +
                              "2. Login");
            AcessarMenu = Convert.ToInt32(Console.ReadLine());
        }//fim do metodo menu




        public void ExecutarMenu()
        {
            do
            {
                PrimeiroMenu();
                //executando a ação
                switch(AcessarMenu)
                {
                    case 0:
                        Console.WriteLine("Obrigado!");
                        break;


                    case 1:
                        Console.WriteLine("Crie um login: ");
                        string login = Convert.ToString(Console.ReadLine());
                        Console.WriteLine("Crie um senha: ");
                        string senha = Convert.ToString(Console.ReadLine());
                        Console.WriteLine("Informe um codigo: ");
                        int codigo = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Informe um nome: ");
                        string nomeCompleto = Console.ReadLine();
                        Console.WriteLine("Informe um telefone: ");
                        string telefone = Console.ReadLine();
                        Console.WriteLine("informe um endereço: ");
                        string endereco = Console.ReadLine();
                        Console.WriteLine("informe sua data de nascimento: ");
                        DateTime dataNascimento = Convert.ToDateTime(Console.ReadLine());
                        
                        //Passei o dado por parametro para o metodo
                        modelCliente.Cadastrar(codigo, nomeCompleto, telefone, endereco, dataNascimento, login, senha);
                        //Mostro o dado em tela
                        Console.Clear();
                        Console.WriteLine("Cadastro com Sucesso!");
                        conexao.Inserir(nomeCompleto, endereco, telefone, dataNascimento, login, senha);
                        break;






                    case 2:
                        //Pedir para o usuario digitar um codigo
                        Console.WriteLine("Informe o codigo: ");
                        codigo = Convert.ToInt32(Console.ReadLine());
                        //mostrar o resultado da operação
                        Console.WriteLine(modelCliente.Consultar(codigo));
                        Console.Clear();
                        Executar();
                        break;
                   

                }
                    

            } while (AcessarMenu != 0);
        }//fim do executar menu








        //==================================================================  Fim PrimeiroMenu   =============================================================================================






















        //=========================================================================   M E N U  do Cliente   =============================================================================================








        public void MenuCliente()
        {
            Console.WriteLine("Escolha uma das opções abaixo: \n\n" +
                                                   "1. Consultar Informações\n" +
                                                   "2. Consultar Livros\n" +
                                                   "3. Comprar Livros\n" +
                                                   "4. Sair");
            AcessarMenuCliente = Convert.ToInt32(Console.ReadLine());

        }//fim do metodo menu cliente









        public void ExecutarMenuCliente()
        {
            do
            {
                MenuCliente();
                //executar a ação
                switch (AcessarMenuCliente)
                {

                    case 1:

                        Console.Clear();
                        Console.WriteLine(conexaoFuncionario.ConsultarTudoFuncionario());
                        break;






                    case 2:

                       
                        break;






                    case 3:

                    
                        break;





                    case 4:
                      
                        break;






                    default:
                        Console.WriteLine("Codigo informado não é valido!");
                        break;

                }//fim do switch
            } while (AcessarOpcao != 0);



        }//fim do executar













































        //============================================================================================  Menu do Funcionario  =============================================================================================








        public void Menu()
        {
            Console.WriteLine("Escolha uma das opções abaixo: \n\n" +
                                                   "1. Cadastros\n" +
                                                   "2. Consultar Tudo\n" +
                                                   "3. Consultar por Codigo\n" +
                                                   "4. Atualizar\n" +
                                                   "5. Excluir\n" +
                                                   "6. Livros\n" +
                                                   "0. Sair");
            AcessarOpcao = Convert.ToInt32(Console.ReadLine());

        }//fim do metodo menu








        //==========================================================================  Executar do Funcionario  ===========================================================================================





        public void Executar()
        {
            do
            {
                Menu();
                //executar a ação
                switch (AcessarOpcao)
                {

                    case 1:
                        Console.WriteLine("Informe seu nome: ");
                        string nome = Console.ReadLine();
                        Console.WriteLine("Informe seu telefone: ");
                        string telefone = Console.ReadLine();
                        Console.WriteLine("Informe seu endereço: ");
                        string endereco = Console.ReadLine();
                        Console.WriteLine("Informe sua data de nascimento: ");
                        DateTime dataNascimento = Convert.ToDateTime(Console.ReadLine());
                        Console.WriteLine("Informe seu login: ");
                        string login = Console.ReadLine();
                        Console.WriteLine("Informe sua senha: ");
                        string senha = Console.ReadLine();
                        //Utilizando esses dados no metodo inserir
                        Console.Clear();
                        conexao.Inserir(nome, endereco, telefone, dataNascimento, login, senha);
                        break;






                    case 2:

                        Console.Clear();
                        Console.WriteLine(conexao.ConsultarTudo());
                        break;






                    case 3:

                        Console.WriteLine("Informe o codigo do cliente que deseja consultar: ");
                        int codigo = Convert.ToInt32(Console.ReadLine());
                        Console.Clear();
                        Console.WriteLine(conexao.ConsultarTudo(codigo));
                        break;





                    case 4:
                        //solicitar os campos que serão atualizados
                        Console.WriteLine("Informe o campo que deseja atualizar: ");
                        string campo = Console.ReadLine();
                        Console.WriteLine("Informe o novo dado para esse campo: ");
                        string novoDado = Console.ReadLine();
                        Console.WriteLine("Informe o codigo do usuario que deseja atualizar: ");
                        codigo = Convert.ToInt32(Console.ReadLine());
                        //utilizar os dados acima no metodo atualizar
                        Console.WriteLine(conexao.Atualizar(codigo, campo, novoDado));
                        break;






                    case 5:
                        //Solicitar o codigo que vai ser apagado
                        Console.WriteLine("Informe o codigo que deseja apagar: ");
                        codigo = Convert.ToInt32(Console.ReadLine());

                        //mostrar o resultado em tela
                        Console.WriteLine(conexao.Deletar(codigo));
                        break;




                    case 6:


                        Console.Clear();
                        livros.ExecutarLivros();
                        break;
                        




                    default:
                        Console.WriteLine("Codigo informado não é valido!");
                        break;

                }//fim do switch
            } while (AcessarOpcao != 0);



        }//fim do executar









    }//fim da control
}//fim do projeto
