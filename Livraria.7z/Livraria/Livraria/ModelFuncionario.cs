﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Livraria
{
    class ModelFuncionario
    {
        //Declarar variaveis
        private int codigoFuncionario;
        private string nomeCompletoFuncionario;
        private string enderecoFuncionario;
        private string telefoneFuncionario;
        private DateTime dataNascimentoFuncionario;
        private string loginFuncionario;
        private string senhaFuncionario;
        private string menuFuncionario;







        public ModelFuncionario()
        {
            //Instanciando variaveis
            AcessarCodigoFuncionario = 0;
            AcessarNomeFuncionario = "";
            AcessarEnderecoFuncionario = "";
            AcessarTelefoneFuncionario = "";
            AcessarDataNascimentoFuncionario = new DateTime();
            AcessarLoginFuncionario = "";
            AcessarSenhaFuncionario = "";
            AcessarMenuFuncionario = "";


        }//fim do metodo construtor 






        //==============================================================================================================================================================================================



        public string AcessarMenuFuncionario
        {
            get
            {
                return menuFuncionario;
            }
            set
            {
                this.menuFuncionario = value;
            }
        }//fim do metodo de acesso do menu





        //Desenvolver os metodos gets e sets
        public int AcessarCodigoFuncionario
        {
            get
            {
                return codigoFuncionario;
            }
            set
            {
                this.codigoFuncionario = value;
            }
        }//fim do metodo de acesso do codigo



        public string AcessarNomeFuncionario
        {
            get
            {
                return nomeCompletoFuncionario;
            }
            set
            {
                this.nomeCompletoFuncionario = value;
            }
        }//fim do metodo de acesso do nome





        public string AcessarEnderecoFuncionario
        {
            get
            {
                return enderecoFuncionario;
            }
            set
            {
                this.enderecoFuncionario = value;
            }
        }//fim do metodo de acesso do endereco



        public string AcessarTelefoneFuncionario
        {
            get
            {
                return telefoneFuncionario;
            }
            set
            {
                this.telefoneFuncionario = value;
            }
        }//fim do metodo de acesso do telefone


        public DateTime AcessarDataNascimentoFuncionario
        {
            get
            {
                return dataNascimentoFuncionario;
            }
            set
            {
                this.dataNascimentoFuncionario = value;
            }
        }//fim do metodo de acesso do nome




        public string AcessarLoginFuncionario
        {
            get
            {
                return loginFuncionario;
            }
            set
            {
                this.loginFuncionario = value;
            }
        }//fim do metodo de acesso do nome



        public string AcessarSenhaFuncionario
        {
            get
            {
                return senhaFuncionario;
            }
            set
            {
                this.senhaFuncionario = value;
            }
        }//fim do metodo de acesso do nome









        //====================================================================BOTÕES=================================================================================












        public void PrimeiroCadastroFuncionario(int codigoFuncionario, string nomeCompletoFuncionario, string telefoneFuncionario, string enderecoFuncionario, DateTime dataNascimentoFuncionario, string loginfuncionario, string senhaFuncionario)
        {
            AcessarCodigoFuncionario = codigoFuncionario;
            AcessarNomeFuncionario = nomeCompletoFuncionario;
            AcessarTelefoneFuncionario = telefoneFuncionario;
            AcessarEnderecoFuncionario = enderecoFuncionario;
            AcessarDataNascimentoFuncionario = dataNascimentoFuncionario;
            AcessarLoginFuncionario = loginFuncionario;
            AcessarSenhaFuncionario = senhaFuncionario;
        }//fim do metodo primeiro cadastro









        public void CadastrarFuncionario(int codigoFuncionario, string nomeCompletoFuncionario, string telefoneFuncionario, string enderecoFuncionario, DateTime dataNascimentoFuncionario, string loginFuncionario, string senhaFuncionario)
        {
            AcessarCodigoFuncionario = codigoFuncionario;
            AcessarNomeFuncionario = nomeCompletoFuncionario;
            AcessarTelefoneFuncionario = telefoneFuncionario;
            AcessarEnderecoFuncionario = enderecoFuncionario;
            AcessarDataNascimentoFuncionario = dataNascimentoFuncionario;
            AcessarLoginFuncionario = loginFuncionario;
            AcessarSenhaFuncionario = senhaFuncionario;
        }//fim do metodo cadastrar 










        public string ConsultarFuncionario(int codigoFuncionaril)
        {
            if (AcessarCodigoFuncionario == codigoFuncionario)
            {
                return "Codigo: " + AcessarCodigoFuncionario +
                       "\nNome Completo: " + AcessarNomeFuncionario +
                       "\nTelefone: " + AcessarTelefoneFuncionario +
                       "\nEndereço: " + AcessarEnderecoFuncionario +
                       "\nData de Nascimento: " + AcessarDataNascimentoFuncionario +
                       "\nLogin: " + AcessarLoginFuncionario +
                       "\nSenha: " + AcessarSenhaFuncionario;
            }
            else
            {
                return "Codigo Informado Não é Valido!";
            }
        }//fim do metodo Consultar 






        public string AtualizarNomesFuncionario(int codigoFuncionario, string nomeCompletoFuncionario)
        {
            if (AcessarCodigoFuncionario == codigoFuncionario)
            {
                AcessarNomeFuncionario = nomeCompletoFuncionario;
                return "Nome atualizado com Sucesso!";
            }
            else
            {
                return "Codigo Informado Não é Valido!";
            }
        }//fim do metodo atualizarNome






        public string AtualizarTelefoneFuncionario(int codigoFuncionario, string telefoneFuncionario)
        {
            if (AcessarCodigoFuncionario == codigoFuncionario)
            {
                AcessarTelefoneFuncionario = telefoneFuncionario;
                return "Telefone Atualizado com Sucesso";
            }
            else
            {
                return "Codigo digitado não é valido!";
            }
        }//fim do metodo atualizarTelefone





        public string AtualizarEnderecoFuncionario(int codigoFuncionario, string enderecoFuncionario)
        {
            if (AcessarCodigoFuncionario == codigoFuncionario)
            {
                AcessarEnderecoFuncionario = enderecoFuncionario;
                return "Endereço Atualizado com Sucesso";
            }
            else
            {
                return "Codigo digitado não é valido!";
            }
        }//fim do metodo atualizar Endereco





        public string AtualizarDataNascimentoFuncionario(int codigoFuncionario, DateTime dataNascimentoFuncionario)
        {
            if (AcessarCodigoFuncionario == codigoFuncionario)
            {
                AcessarDataNascimentoFuncionario = dataNascimentoFuncionario;
                return "Data Atualizado com Sucesso";
            }
            else
            {
                return "Codigo digitado não é valido!";
            }
        }//fim do metodo atualizar data nascimento







        public string AtualizarLoginFuncionario(int codigoFuncionario, string loginFuncionario)
        {
            if (AcessarCodigoFuncionario == codigoFuncionario)
            {
                AcessarLoginFuncionario = loginFuncionario;
                return "Login Atualizado com Sucesso";
            }
            else
            {
                return "Codigo digitado não é valido!";
            }
        }//fim do metodo atualizar login




        public string AtualizarSenhaFuncionario(int codigoFuncionario, string senhaFuncionario)
        {
            if (AcessarCodigoFuncionario == codigoFuncionario)
            {
                AcessarSenhaFuncionario = senhaFuncionario;
                return "Data Atualizado com Sucesso";
            }
            else
            {
                return "Codigo digitado não é valido!";
            }
        }//fim do metodo atualizar senha





    }//fim da classe ModelCliente
}//Fim do projeto
