﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data;
using MySql.Data.MySqlClient;

namespace Livraria
{
    class DAOFuncionario
    {
        public MySqlConnection conexaoFuncionario;
        public string dados;
        public string comando;
        public string resultado;
        public int i;
        public string msg;
        public int contador;
        public int[] codigoFuncionario;//vetor de codigo
        public string[] nomeCompletoFuncionario;//vetor de nome
        public string[] enderecoFuncionario;//vetor de endereco
        public string[] telefoneFuncionario;//vetor de telefone
        public DateTime[] dataNascimentoFuncionario;//vetor de data
        public string[] loginFuncionario;//vetor de login
        public string[] senhaFuncionario;//vetor de senhas






        public DAOFuncionario()
        {
            //Script para o banco de dados
            conexaoFuncionario = new MySqlConnection("server=localhost;DataBase=LivrariaBD;Uid=root;Password=; Convert Zero DateTime = True");
            try
            {
                conexaoFuncionario.Open();//tentando conectar ao BD               
            }
            catch(Exception e)
            {
                Console.WriteLine("Algo deu Errado! \n\n" + e);//mostrar o erro em tela
                Console.ReadLine();//manter o prompt aberto
                conexaoFuncionario.Close();//Fechar a conexao com o banco de dados
            }
        }//fim do metodo construtor










        //Metodo para inserir os dados no BN
        public void InserirFuncionario(string nomeCompletoFuncionario, string enderecoFuncionario, string telefoneFuncionario, DateTime dataNascimentoFuncionario, string loginFuncionario, string senhaFuncionario)
        {
            try
            {
                //modefiicar a estrutura de dados 
                MySqlParameter parameter = new MySqlParameter();
                parameter.ParameterName = "@Date";
                parameter.MySqlDbType = MySqlDbType.Date;
                parameter.Value = dataNascimentoFuncionario.Year + "-" + dataNascimentoFuncionario.Month + "-" + dataNascimentoFuncionario.Day; 


                dados = "('','" + nomeCompletoFuncionario + "','" + enderecoFuncionario + "','" + telefoneFuncionario + "','" + dataNascimentoFuncionario + "','" + loginFuncionario + "','" + senhaFuncionario + "')";
                comando = "Insert into funcionario(codigo, nome, endereco, telefone, dataDeNascimento, login , senha) values" + dados;
               
                
                
                //Executar  o comando de inserção no banco de dados
                MySqlCommand sql = new MySqlCommand(comando, conexaoFuncionario);
                resultado = "" + sql.ExecuteNonQuery();//Executa o insert no BD
                Console.WriteLine(resultado + "Linhas Afetadas");
            }
            catch(Exception e)
            {
                Console.WriteLine("Algo deu Errado!\n\n" + e);
                Console.ReadLine();//Manter o programa aberto
            }
        }//fim do metodo inserir






        public void PreencherVetorFuncionario()
        {
            string query = "select * from Pessoa";//coletar dados do BD

            //Instanciar
            codigoFuncionario = new int[100];
            nomeCompletoFuncionario = new string[100];
            enderecoFuncionario = new string[100];
            telefoneFuncionario = new string[100];
            dataNascimentoFuncionario = new DateTime[100];
            loginFuncionario = new string[100];
            senhaFuncionario = new string[100];



            //Preencher com valores iniciais 
            for (i = 0; i < 100; i++)
            {
                codigoFuncionario[i] = 0;
                nomeCompletoFuncionario[i] = "";
                enderecoFuncionario[i] = "";
                telefoneFuncionario[i] = "";
                dataNascimentoFuncionario[i] = new DateTime();
                loginFuncionario[i] = "";
                senhaFuncionario[i] = "";
            }//fim do for


            //criando um comando para a consulta do banco de dados
            MySqlCommand coletar = new MySqlCommand(query, conexaoFuncionario);
            //lietura dos dados no banco 
            MySqlDataReader leitura = coletar.ExecuteReader();


            i = 0;
            contador = 0;
            while(leitura.Read())
            {
                codigoFuncionario[i] = Convert.ToInt32(leitura["codigo"]);
                nomeCompletoFuncionario[i] = leitura["nome"] + "";
                enderecoFuncionario[i] = leitura["endereco"] + "";
                telefoneFuncionario[i] = leitura["telefone"] + "";
                dataNascimentoFuncionario[i] = Convert.ToDateTime(leitura["dataDeNascimento"]);
                loginFuncionario[i] = leitura["login"] + "";
                senhaFuncionario[i] = leitura["senha"] + "";
                i++;
                contador++;
            }//fim do while


            //fechar leitura de dados no banco
            leitura.Close();

        }//fim do metodo preeenchimento de vetor











        public string ConsultarTudoFuncionario()
        {
            //preencher os vetores
            PreencherVetorFuncionario();


            msg = "";
            for (i = 0; i < contador; i++)
            {
                msg += "Codigo: " + codigoFuncionario[i] +
                        ", Nome: " + nomeCompletoFuncionario[i] +
                        ", Endereco: " + enderecoFuncionario[i] +
                        ", Telefone: " + telefoneFuncionario[i] +
                        ", Data de Nacimento: " + dataNascimentoFuncionario[i] +
                        ", Login: " + loginFuncionario[i] +
                        ", Senha: " + senhaFuncionario[i] +
                        "\n\n";
            }//fim do for


            return msg;

        }//fim do metodo consultar tudo






        public string ConsultarTudoFuncionario(int cod)
        {
            PreencherVetorFuncionario();
            for (i = 0; i < contador; i++)
            {
                if (codigoFuncionario[i] == cod)
                {
                    msg = "Codigo: " + codigoFuncionario[i] +
                    ", Nome: " + nomeCompletoFuncionario[i] +
                    ", Endereço: " + enderecoFuncionario[i] +
                    ", Telefone: " + telefoneFuncionario[i] +                    
                    ", Data de Nascimento: " + dataNascimentoFuncionario[i] +
                    ", Login: " + loginFuncionario[i] +
                    ", Senha: " + senhaFuncionario[i] +
                    "\n\n";
                    return msg;
                }
            }//fim do for


            return "Codigo informado não encontrado";
        }//fim consultar codigo 











        public string AtualizarFuncionario(int codigoFuncionario, string campo, string novoDado)
        {
            try
            {
                string query = "update pessoa set " + campo + " = '" + novoDado + "' where codigo = '" + codigoFuncionario + "'";
                //executar o comando
                MySqlCommand sql = new MySqlCommand(query, conexaoFuncionario);
                string resultado = "" + sql.ExecuteNonQuery();
                return resultado + "Linhas Afetadas";
            }
            catch (Exception e)
            {
                return "Algo deu errado!\n\n" + e;
            }
        }//fim do metodo atualizar









        public string DeletarFuncionario(int codigoFuncionario)
        {
            try
            {
                string query = "delete from Pessoa where codigo = '" + codigoFuncionario + "'";
                //executar o comando
                MySqlCommand sql = new MySqlCommand(query, conexaoFuncionario);
                string resultado = "" + sql.ExecuteNonQuery();
                return resultado + "Linhas Afetadas";
            }
            catch (Exception e)
            {
                return "Algo deu errado!\n\n" + e;
            }
        }//fim do metodo deletar








    }//fim da classe
}//fim do projeto
