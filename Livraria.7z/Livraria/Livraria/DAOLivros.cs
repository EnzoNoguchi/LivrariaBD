﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data;
using MySql.Data.MySqlClient;

namespace Livraria
{
    class DAOLivros
    {
        public MySqlConnection conexaoLivro;
        public string dados;
        public string comando;
        public string resultado;
        public int i;
        public string msg;
        public int contador;
        public int[] codigo;//vetor de codigo
        public string[] titulo;//vetor de titulo
        public double[] preco;//vetor de preco
        public int[] disponibilidade;//vetor de disponibilidade
        public int[] anoLancamento;//vetor de ano lancamento
        public string[] editora;//vetor de editora
        public int[] numPaginas;//vetor de numero de paginas




        public DAOLivros()
        {
            //Script para o banco de dados
            conexaoLivro = new MySqlConnection("server=localhost;DataBase=LivrariaBD;Uid=root;Password=; Convert Zero DateTime = True");
            try
            {
                conexaoLivro.Open();//tentando conectar ao BD               
            }
            catch (Exception e)
            {
                Console.WriteLine("Algo deu Errado! \n\n" + e);//mostrar o erro em tela
                Console.ReadLine();//manter o prompt aberto
                conexaoLivro.Close();//Fechar a conexao com o banco de dados
            }
        }//fim do metodo construtor












        //Metodo para inserir os dados no BN
        public void InserirLivro(string titulo, double preco, int disponibilidade, int anoLancamento, string editora, int numPaginas)
        {
            try
            {
               


                dados = "('','" + titulo + "','" + preco + "','" + disponibilidade + "','" + anoLancamento + "','" + editora + "','" + numPaginas + "')";
                comando = "Insert into livro(codigo, titulo, preco, disponibilidade, anoLancamento, editora, numPaginas) values" + dados;



                //Executar  o comando de inserção no banco de dados
                MySqlCommand sql = new MySqlCommand(comando, conexaoLivro);
                resultado = "" + sql.ExecuteNonQuery();//Executa o insert no BD
                Console.WriteLine(resultado + " Linhas Afetadas");
            }
            catch (Exception e)
            {
                Console.WriteLine("Algo deu Errado!\n\n" + e);
                Console.ReadLine();//Manter o programa aberto
            }
        }//fim do metodo inserir










        public void PreencherVetorLivro()
        {
            string query = "select * from Livro";//coletar dados do BD

            //Instanciar
            codigo = new int[100];
            titulo = new string[100];
            preco = new double[100];
            disponibilidade = new int[100];
            anoLancamento = new int[100];
            editora = new string[100];
            numPaginas = new int[100];










            //Preencher com valores iniciais 
            for (i = 0; i < 100; i++)
            {
                codigo[i] = 0;
                titulo[i] = "";
                preco[i] = 0;
                disponibilidade[i] = 0;
                anoLancamento[i] = 0;
                editora[i] = "";
                numPaginas[i] = 0;
            }//fim do for




            MySqlCommand coletar = new MySqlCommand(query, conexaoLivro);
            //lietura dos dados no banco 
            MySqlDataReader leitura = coletar.ExecuteReader();



            i = 0;
            contador = 0;
            while (leitura.Read())
            {
                codigo[i] = Convert.ToInt32(leitura["codigo"]);
                titulo[i] = leitura["titulo"] + "";
                preco[i] = Convert.ToDouble(leitura["preco"]);
                disponibilidade[i] = Convert.ToInt32(leitura["disponibilidade"]);
                anoLancamento[i] = Convert.ToInt32(leitura["anoLancamento"]);
                editora[i] = leitura["login"] + "";
                numPaginas[i] = Convert.ToInt32(leitura["senha"]);
                i++;
                contador++;
            }//fim do while

            //fechar leitura de dados no banco
            leitura.Close();
        }//fim do metodo preenchimento de vetor













        public string ConsultarTudoLivro()
        {
            //preencher os vetores
            PreencherVetorLivro();


            msg = "";
            for (i = 0; i < contador; i++)
            {
                msg += "Codigo: " + codigo[i] +
                        ", Titulo: " + titulo[i] +
                        ", Preco: " + preco[i] +
                        ", Disponibilidade: " + disponibilidade[i] +
                        ", Ano de Lançamento: " + anoLancamento[i] +
                        ", Editora: " + editora[i] +
                        ", Numero de Paginas: " + numPaginas[i] +
                        "\n\n";
            }//fim do for


            return msg;

        }//fim do metodo consultar tudo






        public string ConsultarTudoLivro(int cod)
        {
            PreencherVetorLivro();
            for (i = 0; i < contador; i++)
            {
                if (codigo[i] == cod)
                {
                    msg = "Codigo: " + codigo[i] +
                    ", Titulo: " + titulo[i] +
                    ", Preço: " + preco[i] +
                    ", Disponibilidade: " + disponibilidade[i] +
                    ", Ano de Lançamento: " + anoLancamento[i] +
                    ", Editora: " + editora[i] +
                    ", Numero de Paginas: " + numPaginas[i] +
                    "\n\n";
                    return msg;
                }
            }//fim do for


            return "Codigo informado não encontrado";
        }//fim consultar codigo 







        public string AtualizarLivro(int codigo, string campo, string novoDado)
        {
            try
            {
                string query = "update Livro set " + campo + " = '" + novoDado + "' where codigo = '" + codigo + "'";
                //executar o comando
                MySqlCommand sql = new MySqlCommand(query, conexaoLivro);
                string resultado = "" + sql.ExecuteNonQuery();
                return resultado + "Linhas Afetadas";
            }
            catch (Exception e)
            {
                return "Algo deu errado!\n\n" + e;
            }
        }//fim do metodo atualizar








        public string DeletarLivro(int codigo)
        {
            try
            {
                string query = "delete from Livro where codigo = '" + codigo + "'";
                //executar o comando
                MySqlCommand sql = new MySqlCommand(query, conexaoLivro);
                string resultado = "" + sql.ExecuteNonQuery();
                return resultado + "Linhas Afetadas";
            }
            catch (Exception e)
            {
                return "Algo deu errado!\n\n" + e;
            }
        }//fim do metodo deletar





    }// fim da classe
}//fim do porjeto 
