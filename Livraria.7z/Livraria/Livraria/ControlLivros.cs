﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Livraria
{
    class ControlLivros
    {
        DAOLivros conexaoLivro;
        Livros livros;
        private int opcao;
        private int menu3;
     
        




        public ControlLivros()
        {
            livros = new Livros();
            conexaoLivro = new DAOLivros();//instanciando a variavel conexao
        }//fim do construtor



        //==============================================================================================================================================================================================








        public int AcessarOpcao
        {
            get
            {
                return opcao;
            }
            set
            {
                this.opcao = value;
            }
        }//fim da opcao










        public int AcessarMenu3
        {
            get
            {
                return menu3;
            }
            set
            {
                this.menu3 = value;
            }
        }//fim do AcessarMenu










        //============================================================================================  M E N U   =============================================================================================



        public void Menu3()
        {
            Console.WriteLine("Escolha uma das opções abaixo: \n\n" +
                                                   "1. Cadastrar Livro\n" +
                                                   "2. Consultar Tudo\n" +
                                                   "3. Consultar por Codigo\n" +
                                                   "4. Atualizar\n" +
                                                   "5. Excluir\n" +
                                                   "0. Sair");
            AcessarOpcao = Convert.ToInt32(Console.ReadLine());

        }//fim do metodo menu





        //===================================================================================================================================================================================================================================================================================





        public void ExecutarLivros()
        {
            do
            {
                Menu3();
                //executar a ação
                switch (AcessarOpcao)
                {

                    case 1:
                        Console.WriteLine("Informe um titulo: ");
                        string titulo = Console.ReadLine();
                        Console.WriteLine("Informe um preço: ");
                        double preco = Convert.ToDouble(Console.ReadLine());
                        Console.WriteLine("Informe a disponibilidade: ");
                        int disponibilidade = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Informe o Ano de Lançamento: ");
                        int anoLancamento = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Informe a editora: ");
                        string editora = Console.ReadLine();
                        Console.WriteLine("Informe o numero de paginas: ");
                        int numPaginas = Convert.ToInt32(Console.ReadLine());
                        //Utilizando esses dados no metodo inserir
                        Console.Clear();
                        conexaoLivro.InserirLivro(titulo, preco, disponibilidade, anoLancamento, editora, numPaginas);
                        break;







                    case 2:

                        Console.Clear();
                        Console.WriteLine(conexaoLivro.ConsultarTudoLivro());
                        break;









                    case 3:

                        Console.WriteLine("Informe o codigo do livro que deseja consultar: ");
                        int codigo = Convert.ToInt32(Console.ReadLine());
                        Console.Clear();
                        Console.WriteLine(conexaoLivro.ConsultarTudoLivro(codigo));
                        break;










                    case 4:
                        //solicitar os campos que serão atualizados
                        Console.WriteLine("Informe o campo que deseja atualizar: ");
                        string campo = Console.ReadLine();
                        Console.WriteLine("Informe o novo dado para esse campo: ");
                        string novoDado = Console.ReadLine();
                        Console.WriteLine("Informe o codigo do usuario que deseja atualizar: ");
                        codigo = Convert.ToInt32(Console.ReadLine());
                        //utilizar os dados acima no metodo atualizar
                        Console.WriteLine(conexaoLivro.AtualizarLivro(codigo, campo, novoDado));
                        break;









                    case 5:
                        //Solicitar o codigo que vai ser apagado
                        Console.WriteLine("Informe o codigo que deseja apagar: ");
                        codigo = Convert.ToInt32(Console.ReadLine());

                        //mostrar o resultado em tela
                        Console.WriteLine(conexaoLivro.DeletarLivro(codigo));
                        break;













                    default:
                        Console.WriteLine("Codigo informado não é valido!");
                        break;



                }//fim do switch
            } while (AcessarOpcao != 0);



        }//fim do executar




    }//fim da classe
}//fim do projeto
